PARAMS = \
{
	"env" : "FrozenLake-v0",
	"is_slippery" : False,
	"size_idx" : {
	"4x4": 4, 
	"8x8": 8
	},
	"map_name": "8x8",
	"epsilon": 0.9,
	"epochs": 8000,
	"max_steps": 100,
	"lr": .81,
	"gamma": .96,
	"Train_render": False,
	"Test_Visrender": True,
	"save_result": False,

}
